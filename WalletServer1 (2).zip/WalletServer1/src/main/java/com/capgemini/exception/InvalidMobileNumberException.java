package com.capgemini.exception;

public class InvalidMobileNumberException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidMobileNumberException(String msg) {
		super(msg);
	}

}
